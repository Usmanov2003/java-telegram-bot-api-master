package com.pengrad.telegrambot.model.botcommandscope

class BotCommandScopeAllChatAdministrators : BotCommandScope(type = "all_chat_administrators")