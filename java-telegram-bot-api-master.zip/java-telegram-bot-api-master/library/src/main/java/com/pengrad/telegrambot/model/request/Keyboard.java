package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

/**
 * stas
 * 8/11/15
 */
public abstract class Keyboard implements Serializable {
    private final static long serialVersionUID = 0L;
}
