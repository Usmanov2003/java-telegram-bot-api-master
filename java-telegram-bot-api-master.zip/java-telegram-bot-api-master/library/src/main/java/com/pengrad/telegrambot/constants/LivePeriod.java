package com.pengrad.telegrambot.constants;

public class LivePeriod {

    public final static Integer INFINITE_LIVE_PERIOD = Integer.MAX_VALUE;

    private LivePeriod() { }
    
}
