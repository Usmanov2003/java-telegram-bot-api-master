package com.pengrad.telegrambot.model.botcommandscope

open class BotCommandScope(val type: String)