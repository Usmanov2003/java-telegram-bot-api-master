package com.pengrad.telegrambot.model.botcommandscope

class BotCommandScopeDefault : BotCommandScope(type = "default")
