package com.pengrad.telegrambot.model.botcommandscope

class BotCommandScopeAllGroupChats : BotCommandScope(type = "all_group_chats")
