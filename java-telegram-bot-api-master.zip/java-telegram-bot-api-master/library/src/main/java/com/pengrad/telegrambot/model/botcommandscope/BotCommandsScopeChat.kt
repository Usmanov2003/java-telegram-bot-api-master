package com.pengrad.telegrambot.model.botcommandscope

class BotCommandsScopeChat(val chatId: Any) : BotCommandScope(type = "chat")