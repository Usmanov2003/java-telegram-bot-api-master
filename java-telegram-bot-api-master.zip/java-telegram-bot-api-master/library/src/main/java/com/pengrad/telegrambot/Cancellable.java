package com.pengrad.telegrambot;

public interface Cancellable {
    void cancel();
}
