package com.pengrad.telegrambot.model.botcommandscope

class BotCommandScopeAllPrivateChats : BotCommandScope(type = "all_private_chats")
