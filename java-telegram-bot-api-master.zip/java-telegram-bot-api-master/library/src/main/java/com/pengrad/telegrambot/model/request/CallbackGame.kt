package com.pengrad.telegrambot.model.request

/**
 * Stas Parshin
 * 04 June 2019
 */
object CallbackGame


