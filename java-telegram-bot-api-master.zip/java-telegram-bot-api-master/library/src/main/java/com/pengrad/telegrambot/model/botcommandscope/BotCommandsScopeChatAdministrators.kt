package com.pengrad.telegrambot.model.botcommandscope

class BotCommandsScopeChatAdministrators(val chatId: Any) : BotCommandScope(type = "chat_administrators")