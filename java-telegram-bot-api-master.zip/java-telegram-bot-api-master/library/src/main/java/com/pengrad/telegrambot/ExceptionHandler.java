package com.pengrad.telegrambot;

/**
 * Stas Parshin
 * 14 June 2019
 */
public interface ExceptionHandler {

    void onException(TelegramException e);

}
